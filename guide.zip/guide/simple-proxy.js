const express = require("express");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
app.use(express.json());

const USER_TOKEN = process.env.USER_TOKEN;
if (!USER_TOKEN) {
    console.error("Missing USER_TOKEN environment variable");
    process.exit(1);
}

// Locate and load WASM solver module in the same folder
const WASM_PATH = path.join(__dirname, "sha3_wasm_bg.wasm");
let wasmInstance = null;

async function initWasm() {
    console.log(`Loading WASM from ${WASM_PATH}...`);
    if (!fs.existsSync(WASM_PATH)) {
        throw new Error(`WASM file not found at ${WASM_PATH}. Please ensure sha3_wasm_bg.wasm is placed in the same directory.`);
    }
    const wasmBuffer = fs.readFileSync(WASM_PATH);
    const wasmModule = await WebAssembly.compile(wasmBuffer);
    wasmInstance = await WebAssembly.instantiate(wasmModule, {});
    console.log("WASM solver loaded successfully.");
}

function generateUUID() {
    return crypto.randomBytes(16).toString('hex');
}

// Solve the DeepSeekHashV1 challenge using loaded WASM module
function solveChallenge(config) {
    if (!wasmInstance) {
        throw new Error("WASM solver not initialized");
    }
    const mem = wasmInstance.exports.memory;
    const prefix = `${config.salt}_${config.expire_at}_`;

    function writeString(str) {
        const encoded = Buffer.from(str, 'utf-8');
        const length = encoded.length;
        const ptr = wasmInstance.exports.__wbindgen_export_0(length, 1);
        const view = new Uint8Array(mem.buffer);
        for (let i = 0; i < length; i++) {
            view[ptr + i] = encoded[i];
        }
        return { ptr, length };
    }

    const retptr = wasmInstance.exports.__wbindgen_add_to_stack_pointer(-16);
    try {
        const challengeInfo = writeString(config.challenge);
        const prefixInfo = writeString(prefix);

        wasmInstance.exports.wasm_solve(
            retptr,
            challengeInfo.ptr,
            challengeInfo.length,
            prefixInfo.ptr,
            prefixInfo.length,
            config.difficulty
        );

        const view = new Int32Array(mem.buffer);
        const status = view[retptr / 4];
        if (status === 0) {
            throw new Error('wasm_solve returned 0 — no solution found');
        }

        const floatView = new Float64Array(mem.buffer);
        const value = floatView[(retptr + 8) / 8];
        const answer = Math.floor(value);

        const result = {
            algorithm: config.algorithm,
            challenge: config.challenge,
            salt: config.salt,
            answer: answer,
            signature: config.signature,
            target_path: config.target_path
        };

        return Buffer.from(JSON.stringify(result)).toString('base64');
    } finally {
        wasmInstance.exports.__wbindgen_add_to_stack_pointer(16);
    }
}

// Parses the text/event-stream response and accumulates the assistant's reply
function parseSseText(sseText) {
    const lines = sseText.split('\n');
    let accumulatedContent = '';
    let phase = 'thinking';
    let fragmentType = null;

    for (let line of lines) {
        line = line.trim();
        if (!line) continue;
        if (line.startsWith('event:')) continue;
        if (line.startsWith(':') || line === ':') continue;
        if (line.startsWith('<!DOCTYPE') || line.startsWith('<html') || line.startsWith('<HTML')) {
            throw new Error(`DeepSeek returned HTML error: ${line.substring(0, 200)}`);
        }

        let ds = line;
        if (line.startsWith('data: ')) {
            ds = line.substring(6);
        }
        ds = ds.trim();
        if (!ds) continue;
        if (ds === ':') continue;
        if (ds === '[DONE]') break;

        try {
            const obj = JSON.parse(ds);
            if (obj && typeof obj === 'object') {
                if (obj.code && obj.code >= 40000) {
                    throw new Error(`DeepSeek error (${obj.code}): ${obj.msg}`);
                }
                if (obj.type === 'error') {
                    throw new Error(`DeepSeek stream error: ${obj.content} (${obj.finish_reason})`);
                }

                const val = obj.v;
                const path = obj.p;

                if (typeof val === 'object' && val !== null) {
                    if (val.type === 'error' && val.finish_reason) {
                        throw new Error(`DeepSeek stream error: ${val.content} (${val.finish_reason})`);
                    }
                    const respData = val.response;
                    if (respData && typeof respData === 'object') {
                        const frags = respData.fragments;
                        if (Array.isArray(frags)) {
                            for (const frag of frags) {
                                if (frag && typeof frag === 'object') {
                                    if (frag.type) {
                                        fragmentType = frag.type;
                                    }
                                    if (frag.content && typeof frag.content === 'string') {
                                        const isThink = (fragmentType === 'THINK');
                                        if (!isThink) {
                                            phase = 'content';
                                            accumulatedContent += frag.content;
                                        } else {
                                            phase = 'thinking';
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (path === 'response/fragments' && obj.o === 'APPEND' && Array.isArray(val)) {
                    if (val.length > 0) {
                        const lastFrag = val[val.length - 1];
                        if (lastFrag && typeof lastFrag === 'object') {
                            if (lastFrag.type) {
                                fragmentType = lastFrag.type;
                            }
                            if (lastFrag.content && typeof lastFrag.content === 'string') {
                                const isThink = (fragmentType === 'THINK');
                                if (!isThink) {
                                    phase = 'content';
                                    accumulatedContent += lastFrag.content;
                                } else {
                                    phase = 'thinking';
                                }
                            }
                        }
                    }
                } else if (path === 'response/fragments/-1/content') {
                    const isThink = (fragmentType === 'THINK');
                    if (typeof val === 'string') {
                        if (!isThink) {
                            phase = 'content';
                            accumulatedContent += val;
                        } else {
                            phase = 'thinking';
                        }
                    }
                } else if (path === 'response/content') {
                    phase = 'content';
                    if (typeof val === 'string') {
                        accumulatedContent += val;
                    }
                } else if (path === 'response/thinking_content') {
                    phase = 'thinking';
                } else if (!path) {
                    // Pathless continuation line
                    if (typeof val === 'string' && val) {
                        const isThinking = (fragmentType !== null) ? (fragmentType === 'THINK') : (phase === 'thinking');
                        if (!isThinking) {
                            accumulatedContent += val;
                        }
                    }
                }
            }
        } catch (e) {
            if (e.message && e.message.startsWith('DeepSeek')) {
                throw e;
            }
            // ignore general json parsing error for debug/log statements
        }
    }
    return accumulatedContent;
}

function convertMessagesToPrompt(messages) {
    const BOS = "<｜begin▁of▁sentence｜>";
    const SYS = "<｜System｜>";
    const USER = "<｜User｜>";
    const ASST = "<｜Assistant｜>";
    const EOS = "<｜end▁of▁sentence｜>";
    const SYS_END = "<｜end▁of▁instructions｜>";

    let parts = [BOS];
    for (const msg of messages) {
        const role = msg.role;
        const content = msg.content || "";

        if (role === "system") {
            if (content.trim()) {
                parts.push(SYS + content + SYS_END);
            }
        } else if (role === "user") {
            let text = "";
            if (Array.isArray(content)) {
                text = content
                    .filter(p => p && p.type === "text")
                    .map(p => p.text || "")
                    .join(" ");
            } else {
                text = String(content);
            }
            parts.push(USER + text);
        } else if (role === "assistant") {
            let text = String(content);
            parts.push(ASST + text + EOS);
        }
    }
    
    const lastMsg = messages[messages.length - 1];
    if (lastMsg && lastMsg.role !== "assistant") {
        parts.push(ASST);
    }

    return parts.join("");
}

app.post("/v1/chat/completions", async (req, res) => {
    let rawSessionId = null;
    const headers = {
        "Content-Type": "application/json",
        "Accept": "*/*",
        "Authorization": `Bearer ${USER_TOKEN}`,
        "Origin": "https://chat.deepseek.com",
        "Referer": "https://chat.deepseek.com/",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "x-client-platform": "web",
        "x-client-version": "1.3.0-auto-resume",
        "x-client-locale": "en-US",
        "x-app-version": "20241129.1"
    };

    try {
        const lastMessage = req.body.messages[req.body.messages.length - 1];

        // 1. Create a fresh session on DeepSeek
        console.log("Creating session on DeepSeek...");
        const sessResp = await fetch("https://chat.deepseek.com/api/v0/chat_session/create", {
            method: "POST",
            headers: headers,
            body: JSON.stringify({})
        });

        if (!sessResp.ok) {
            const errText = await sessResp.text();
            console.error("Failed to create session:", errText);
            return res.status(sessResp.status).json({ error: "Failed to create DeepSeek session", details: errText });
        }

        const sessJson = await sessResp.json();
        if (sessJson.code !== 0 || !sessJson.data?.biz_data?.id) {
            console.error("Invalid session response:", sessJson);
            return res.status(500).json({ error: "Invalid session structure from DeepSeek", details: sessJson });
        }

        rawSessionId = sessJson.data.biz_data.id;
        // Normalize: Strip dashes for chat completions as required
        const chatSessionId = rawSessionId.replace(/-/g, "");
        console.log(`Session created: ${rawSessionId} -> normalized: ${chatSessionId}`);

        // 2. Fetch the PoW challenge
        console.log("Fetching PoW challenge from DeepSeek...");
        const powChallengeRes = await fetch("https://chat.deepseek.com/api/v0/chat/create_pow_challenge", {
            method: "POST",
            headers: headers,
            body: JSON.stringify({ target_path: "/api/v0/chat/completion" })
        });

        if (!powChallengeRes.ok) {
            const errText = await powChallengeRes.text();
            console.error("Failed to fetch challenge:", errText);
            return res.status(powChallengeRes.status).json({ error: "Failed to fetch PoW challenge", details: errText });
        }

        const powChallengeJson = await powChallengeRes.json();
        if (powChallengeJson.code !== 0 || !powChallengeJson.data?.biz_data?.challenge) {
            console.error("Invalid PoW challenge response:", powChallengeJson);
            return res.status(500).json({ error: "Invalid PoW challenge structure", details: powChallengeJson });
        }

        const challengeConfig = powChallengeJson.data.biz_data.challenge;
        console.log(`Solving challenge (difficulty: ${challengeConfig.difficulty})...`);

        // 3. Solve the challenge
        const solvedPow = solveChallenge(challengeConfig);
        console.log("Challenge solved!");

        // 4. Request completion with solved PoW attached
        const completionHeaders = {
            ...headers,
            "x-ds-pow-response": solvedPow
        };

        const completionBody = {
            chat_session_id: chatSessionId,
            parent_message_id: null,
            prompt: convertMessagesToPrompt(req.body.messages),
            ref_file_ids: [],
            thinking_enabled: false,
            search_enabled: false
        };

        console.log("Requesting chat completion from DeepSeek...");
        const completionRes = await fetch("https://chat.deepseek.com/api/v0/chat/completion", {
            method: "POST",
            headers: completionHeaders,
            body: JSON.stringify(completionBody)
        });

        const completionText = await completionRes.text();
        if (!completionRes.ok) {
            console.error("DeepSeek completion error:", completionText);
            return res.status(completionRes.status).json({ error: "DeepSeek completion error", details: completionText });
        }

        // 5. Parse response and format to OpenAI response shape
        let assistantReply;
        try {
            assistantReply = parseSseText(completionText);
        } catch (parseErr) {
            console.error("Error parsing response stream:", parseErr);
            return res.status(500).json({ error: "Error parsing DeepSeek stream response", details: parseErr.message });
        }

        const openAiResponse = {
            choices: [
                {
                    message: {
                        role: "assistant",
                        content: assistantReply
                    },
                    index: 0,
                    finish_reason: "stop"
                }
            ]
        };

        return res.json(openAiResponse);

    } catch (err) {
        console.error("Internal Server Error:", err);
        res.status(500).json({ error: err.message });
    } finally {
        if (rawSessionId) {
            console.log(`Cleaning up session ${rawSessionId}...`);
            fetch("https://chat.deepseek.com/api/v0/chat_session/delete", {
                method: "POST",
                headers: headers,
                body: JSON.stringify({ chat_session_id: rawSessionId })
            }).then(deleteRes => {
                if (deleteRes.ok) {
                    console.log(`Successfully deleted session ${rawSessionId}`);
                } else {
                    console.error(`Failed to delete session ${rawSessionId}`);
                }
            }).catch(deleteErr => {
                console.error(`Error deleting session ${rawSessionId}:`, deleteErr);
            });
        }
    }
});

const PORT = 5001;
(async () => {
    try {
        await initWasm();
        app.listen(PORT, () => console.log(`Simple proxy running on http://localhost:${PORT}`));
    } catch (err) {
        console.error("Failed to initialize WASM solver or start proxy:", err);
        process.exit(1);
    }
})();
