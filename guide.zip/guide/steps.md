# DeepSeek Web Chat Proxy Setup Guide

This guide describes how to run and test this self-contained Node.js / Express proxy that exposes an OpenAI-compatible `/v1/chat/completions` endpoint and routes prompts to DeepSeek's internal web-chat API. It includes an integrated, high-performance in-memory WebAssembly (WASM) Proof-of-Work (PoW) solver.

The proxy supports both streaming (SSE) and non-streaming client requests, translating DeepSeek's internal stream format on-the-fly.

---

## 1. Prerequisites
- **Node.js**: Version 18 or newer (to support the native `fetch` API).
- **DeepSeek Web Session Token**: A valid authorization token from a logged-in session on [chat.deepseek.com](https://chat.deepseek.com).

---

## 2. Directory Structure
Ensure that all files in this setup reside in the same directory:
```text
guide/
├── package.json         # Package configuration with dependencies
├── simple-proxy.js      # Main Express application containing proxy logic
├── sha3_wasm_bg.wasm    # WebAssembly binary for the SHA3-based PoW solver
└── steps.md             # This setup guide
```

---

## 3. Installation Steps

### Step 3.1: Copy Files
Copy the `guide/` folder containing the four files to your target Ubuntu or Linux machine.

### Step 3.2: Install Dependencies
Open a terminal in the directory where the files are stored and run:
```bash
npm install
```
*This installs Express (`express`) as defined in `package.json`.*

---

## 4. Configuration

To authorize requests to DeepSeek, you must set your web session token as an environment variable named `USER_TOKEN`.

### Obtaining your Token
1. Open your browser and go to [chat.deepseek.com](https://chat.deepseek.com).
2. Log in to your account.
3. Open the browser's Developer Tools (F12) and go to the **Network** tab.
4. Perform any action (like sending a chat message) and look at the request headers for any request going to `https://chat.deepseek.com/api/v0/...`.
5. Copy the value of the `Authorization` header after the prefix `Bearer `. This string starting with your credentials is your `USER_TOKEN`.

### Setting the Environment Variable
In your terminal, run:
```bash
export USER_TOKEN="your_copied_token_here"
```

---

## 5. Running the Proxy Server

To start the server, run:
```bash
npm start
```
*Alternatively, you can run `node simple-proxy.js` directly.*

Upon successful initialization, you will see the following logs:
```text
Loading WASM from /path/to/guide/sha3_wasm_bg.wasm...
WASM solver loaded successfully.
Simple proxy running on http://localhost:5001
```

---

## 6. Testing the Proxy

With the server running on port `5001`, you can test it by sending a standard OpenAI-compatible completions POST request.

Run the following `curl` command from another terminal window:

```bash
curl -X POST http://localhost:5001/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {
        "role": "user",
        "content": "Say hi"
      }
    ],
    "model": "deepseek-chat"
  }'
```

### Testing Streaming Mode

To test the streaming response, set `"stream": true` in the request body:

```bash
curl -X POST http://localhost:5001/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {
        "role": "user",
        "content": "Say hi"
      }
    ],
    "model": "deepseek-chat",
    "stream": true
  }'
```

This will return a stream of Server-Sent Events (SSE) in standard OpenAI formatting:
```text
data: {"choices":[{"delta":{"content":"Hi"},"index":0,"finish_reason":null}]}
...
data: [DONE]
```

### Expected Response Format (Non-Streaming)
The proxy processes the request, creates a temporary session in the background, solves the anti-bot Proof-of-Work challenge in WebAssembly, sends the prompt, parses the SSE response stream, cleans up/deletes the chat session, and returns the response in a standard OpenAI format:

```json
{
  "choices": [
    {
      "message": {
        "role": "assistant",
        "content": "Hi there! How can I help you today?"
      },
      "index": 0,
      "finish_reason": "stop"
    }
  ]
}
```

---

## 7. Troubleshooting

- **Error: "Missing USER_TOKEN environment variable"**
  Make sure you exported `USER_TOKEN` in the active shell where you started the proxy (`export USER_TOKEN="..."`).
- **Error: "WASM file not found at..."**
  Ensure that `sha3_wasm_bg.wasm` is placed in the exact same folder as `simple-proxy.js`.
- **401 Unauthorized Response**
  Your DeepSeek web token may have expired or is invalid. Log back in to [chat.deepseek.com](https://chat.deepseek.com) and extract a new token from the request headers.
