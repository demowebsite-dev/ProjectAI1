# 100% Free, Ban-Proof LLM Integration Guide for Hermes

If you do not want to spend money on API credits and want a stable, ban-proof connection for your Hermes Agent, you should use **official developer free tiers** instead of scraping/proxying web interfaces. 

Here is the best 100% free approach:

---

## The Recommended Approach: Google Gemini API (High Limit & Stable)
Google provides a very generous free tier for its Gemini models through Google AI Studio. 

### Why it is stable:
* **Large Context Limit**: Gemini 2.5 Flash has a **1 million token context window**, which easily accommodates Hermes' system prompts and tool schemas baseline (which takes ~26,000 tokens).
* **High Rate Limits**: 
  * **15 requests per minute (RPM)**
  * **1,500 requests per day (RPD)**
* **100% Free**: No credit card or registration fee required.

### How to configure in Hermes:
1. Go to [Google AI Studio](https://aistudio.google.com/) and create a free API Key.
2. Open your Hermes environment file ([.env](file:///home/codespace/.hermes/.env)) and add the key:
   ```env
   GEMINI_API_KEY=your_gemini_api_key_here
   ```
3. Open [config.yaml](file:///home/codespace/.hermes/config.yaml) and update the default model at the top:
   ```yaml
   model:
     default: gemini-2.5-flash
     provider: gemini
   ```
4. Restart your Hermes gateway to apply the new settings:
   ```bash
   hermes gateway stop
   hermes gateway start
   ```

---

## Why GitHub Models API Cannot Be Used
While GitHub Models provides free developer access to models like `gpt-4o-mini`, it enforces a strict limit of **8,000 max tokens per request**. 
Because Hermes loads a comprehensive suite of system prompts, agent personalities, and tool definitions, its baseline payload exceeds **26,000 tokens** before a conversation even begins. Calling GitHub Models with Hermes will immediately fail with an `HTTP 413: Request payload too large` error.
