# 100% Free, Ban-Proof LLM Integration Guide for Hermes

If you do not want to spend money on API credits and want a stable, ban-proof connection for your Hermes Agent, you should use **official developer free tiers** instead of scraping/proxying web interfaces. 

Here are the best 100% free approaches:

---

## Approach 1: GitHub Models API (Immediate & Easiest)
Since you are running inside a GitHub Codespace, you already have an active `GITHUB_TOKEN` environment variable. GitHub provides developers with **free access** to top-tier models (like `gpt-4o-mini`, `gpt-4o`, `Meta-Llama-3.1-70B-Instruct`, and more).

### Why it is stable:
* **100% Free**: No credit card or registration needed.
* **No Ban Risk**: It is an official developer playground tier provided by GitHub.
* **Uses Your Existing Token**: It automatically uses the `GITHUB_TOKEN` already set in your Codespace shell!

### How to configure in Hermes:
1. Open your Hermes configuration file ([config.yaml](file:///home/codespace/.hermes/config.yaml)).
2. At the top of the file, set the default model and provider:
   ```yaml
   model:
     default: gpt-4o-mini
     provider: github-models
   ```
3. Under the `custom_providers` section, add the GitHub Models registration:
   ```yaml
   custom_providers:
     - name: github-models
       base_url: https://models.inference.ai.azure.com
       api_key: <your_codespace_github_token>
       model: gpt-4o-mini
   ```
   *(To get your actual token value, run `echo $GITHUB_TOKEN` in your terminal and paste it in place of `<your_codespace_github_token>`)*

---

## Approach 2: Google Gemini API (High Rate Limits)
Google provides a very generous free tier for its Gemini models through Google AI Studio. 

### Free Tier Limits (Gemini 2.5 Flash):
* **15 requests per minute (RPM)**
* **1,500 requests per day (RPD)**
* **100% Free** (with a massive 1M token context window)

### How to configure in Hermes:
1. Go to [Google AI Studio](https://aistudio.google.com/) and create a free API Key.
2. Open your Hermes environment file ([.env](file:///home/codespace/.hermes/.env)) and add the key:
   ```env
   GEMINI_API_KEY=your_gemini_api_key_here
   ```
3. Open [config.yaml](file:///home/codespace/.hermes/config.yaml) and update the default model at the top:
   ```yaml
   model:
     default: gemini-2.5-flash
     provider: gemini
   ```

---

## Approach 3: Groq Free Developer Tier (Ultra-Fast)
Groq offers an incredibly fast and free developer tier for running open-source models like Llama 3.1 and Gemma 2.

### How to configure in Hermes:
1. Register for a free account on [Groq Console](https://console.groq.com/).
2. Create an API Key.
3. Open your Hermes environment file ([.env](file:///home/codespace/.hermes/.env)) and add:
   ```env
   GROQ_API_KEY=your_groq_api_key_here
   ```
4. Configure the model in [config.yaml](file:///home/codespace/.hermes/config.yaml):
   ```yaml
   model:
     default: llama-3.1-70b-versatile
     provider: groq
   ```
